#include "SerialAddin.h"

AddinType SerialAddinTemplate::type()
{
	return AddinType::ADDIN_TYPE_PROGRESS;
}

int SerialAddinTemplate::status()
{
	return 0;
}

void SerialAddinTemplate::callback()
{
	printf("callback\n");
}
