#include "SerialAddin.h"

int SerialAddinTemplate::maximum()
{
	return 0;
}

int SerialAddinTemplate::value()
{
	return 0;
}

void SerialAddinTemplate::cancel()
{
}

bool SerialAddinTemplate::finished()
{
	return false;
}

void SerialAddinTemplate::callback()
{
	printf("callback\n");
}
