#pragma once

#include <SerialAddinBase.h>

class SerialAddinTemplate : public SerialAddinBase
{
public:
	SerialAddinTemplate() = default;
	~SerialAddinTemplate() = default;

public:
	virtual AddinType type() override;
	virtual int status() override;
	virtual void callback() override;

};

extern "C" __declspec(dllexport) SerialAddinBase* loadAddin()
{
	return new SerialAddinTemplate;
}