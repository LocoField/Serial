#pragma once

#include <SerialAddinBase.h>

class SerialAddinTemplate : public SerialAddinBase
{
public:
	SerialAddinTemplate() = default;
	~SerialAddinTemplate() = default;

public:
	virtual int maximum() override;
	virtual int value() override;

	virtual void cancel() override;
	virtual bool finished() override;

	virtual void callback() override;

};

extern "C" __declspec(dllexport) SerialAddinBase* loadAddin()
{
	return new SerialAddinTemplate;
}